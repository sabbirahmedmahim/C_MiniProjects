# Student Record System in C

## Features
- Input student name, roll number, and marks
- Saves record to a file student.txt

## How to Run
gcc student.c -o student
./student
