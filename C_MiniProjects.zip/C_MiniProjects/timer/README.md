# Simple Timer in C

## Features
- Countdown timer
- Updates every second

## How to Run
gcc timer.c -o timer
./timer

