# Simple Calculator in C

## Features
- Supports basic operations: +, -, *, /
- Handles division by zero

## How to Run
Compile with any C compiler and run the executable:

gcc calculator.c -o calculator
./calculator

