# Tic-Tac-Toe in C

## Features
- 2-player console game
- Detects win and draw
- Simple numbered board UI

## How to Run
gcc tictactoe.c -o tictactoe
./tictactoe
