#include <stdio.h>

char board[3][3];
int currentPlayer = 1;

void initBoard()
{
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = '1' + (i * 3 + j);
}

void printBoard()
{
    printf("\n");
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf(" %c ", board[i][j]);
            if (j < 2)
                printf("|");
        }
        if (i < 2)
            printf("\n---|---|---\n");
    }
    printf("\n");
}

int checkWin()
{
    for (int i = 0; i < 3; i++)
    {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2])
            return 1;
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i])
            return 1;
    }
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2])
        return 1;
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0])
        return 1;
    return 0;
}

int isDraw()
{
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] != 'X' && board[i][j] != 'O')
                return 0;
    return 1;
}

void makeMove(int pos)
{
    char mark = (currentPlayer == 1) ? 'X' : 'O';
    int row = (pos - 1) / 3;
    int col = (pos - 1) % 3;
    if (board[row][col] != 'X' && board[row][col] != 'O')
    {
        board[row][col] = mark;
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    }
    else
    {
        printf("Invalid move. Try again.\n");
    }
}

int main()
{
    int pos;
    initBoard();
    while (1)
    {
        printBoard();
        printf("Player %d, enter your move (1-9): ", currentPlayer);
        scanf("%d", &pos);
        makeMove(pos);
        if (checkWin())
        {
            printBoard();
            printf("Player %d wins!\n", (currentPlayer == 1) ? 2 : 1);
            break;
        }
        else if (isDraw())
        {
            printBoard();
            printf("It's a draw!\n");
            break;
        }
    }
    return 0;
}