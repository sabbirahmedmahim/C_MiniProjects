# Number Guessing Game in C

## Features
- Random number from 1 to 100
- Feedback on guess
- Counts attempts

## How to Run
gcc guess.c -o guess
./guess
